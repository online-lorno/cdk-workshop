"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const sdk = require("aws-sdk");
exports.handler = async (event) => {
    var _a, _b;
    console.log("request:", JSON.stringify(event, undefined, 2));
    // create AWS SDK clients
    const dynamo = new sdk.DynamoDB();
    const lambda = new sdk.Lambda();
    // update dynamo entry for "path" with hits++
    await dynamo
        .updateItem({
        TableName: (_a = process.env.HITS_TABLE_NAME) !== null && _a !== void 0 ? _a : "",
        Key: { path: { S: event.path } },
        UpdateExpression: "ADD hits :incr",
        ExpressionAttributeValues: { ":incr": { N: "1" } },
    })
        .promise();
    // call downstream function and capture response
    const response = await lambda
        .invoke({
        FunctionName: (_b = process.env.DOWNSTREAM_FUNCTION_NAME) !== null && _b !== void 0 ? _b : "",
        Payload: JSON.stringify(event),
    })
        .promise();
    console.log("downstream response:", JSON.stringify(response, undefined, 2));
    if (response === null || response === void 0 ? void 0 : response.Payload) {
        // return response back to upstream caller
        return JSON.parse(response === null || response === void 0 ? void 0 : response.Payload);
    }
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGl0Y291bnRlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImhpdGNvdW50ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsK0JBQStCO0FBRWxCLFFBQUEsT0FBTyxHQUFRLEtBQUssRUFBRSxLQUFVLEVBQUUsRUFBRTs7SUFDL0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFFN0QseUJBQXlCO0lBQ3pCLE1BQU0sTUFBTSxHQUFHLElBQUksR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ2xDLE1BQU0sTUFBTSxHQUFHLElBQUksR0FBRyxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBRWhDLDZDQUE2QztJQUM3QyxNQUFNLE1BQU07U0FDVCxVQUFVLENBQUM7UUFDVixTQUFTLFFBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLG1DQUFJLEVBQUU7UUFDNUMsR0FBRyxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxJQUFJLEVBQUUsRUFBRTtRQUNoQyxnQkFBZ0IsRUFBRSxnQkFBZ0I7UUFDbEMseUJBQXlCLEVBQUUsRUFBRSxPQUFPLEVBQUUsRUFBRSxDQUFDLEVBQUUsR0FBRyxFQUFFLEVBQUU7S0FDbkQsQ0FBQztTQUNELE9BQU8sRUFBRSxDQUFDO0lBRWIsZ0RBQWdEO0lBQ2hELE1BQU0sUUFBUSxHQUFHLE1BQU0sTUFBTTtTQUMxQixNQUFNLENBQUM7UUFDTixZQUFZLFFBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsbUNBQUksRUFBRTtRQUN4RCxPQUFPLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUM7S0FDL0IsQ0FBQztTQUNELE9BQU8sRUFBRSxDQUFDO0lBRWIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUU1RSxJQUFJLFFBQVEsYUFBUixRQUFRLHVCQUFSLFFBQVEsQ0FBRSxPQUFPLEVBQUU7UUFDckIsMENBQTBDO1FBQzFDLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLGFBQVIsUUFBUSx1QkFBUixRQUFRLENBQUUsT0FBaUIsQ0FBQyxDQUFDO0tBQ2hEO0FBQ0gsQ0FBQyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgc2RrIGZyb20gXCJhd3Mtc2RrXCI7XG5cbmV4cG9ydCBjb25zdCBoYW5kbGVyOiBhbnkgPSBhc3luYyAoZXZlbnQ6IGFueSkgPT4ge1xuICBjb25zb2xlLmxvZyhcInJlcXVlc3Q6XCIsIEpTT04uc3RyaW5naWZ5KGV2ZW50LCB1bmRlZmluZWQsIDIpKTtcblxuICAvLyBjcmVhdGUgQVdTIFNESyBjbGllbnRzXG4gIGNvbnN0IGR5bmFtbyA9IG5ldyBzZGsuRHluYW1vREIoKTtcbiAgY29uc3QgbGFtYmRhID0gbmV3IHNkay5MYW1iZGEoKTtcblxuICAvLyB1cGRhdGUgZHluYW1vIGVudHJ5IGZvciBcInBhdGhcIiB3aXRoIGhpdHMrK1xuICBhd2FpdCBkeW5hbW9cbiAgICAudXBkYXRlSXRlbSh7XG4gICAgICBUYWJsZU5hbWU6IHByb2Nlc3MuZW52LkhJVFNfVEFCTEVfTkFNRSA/PyBcIlwiLFxuICAgICAgS2V5OiB7IHBhdGg6IHsgUzogZXZlbnQucGF0aCB9IH0sXG4gICAgICBVcGRhdGVFeHByZXNzaW9uOiBcIkFERCBoaXRzIDppbmNyXCIsXG4gICAgICBFeHByZXNzaW9uQXR0cmlidXRlVmFsdWVzOiB7IFwiOmluY3JcIjogeyBOOiBcIjFcIiB9IH0sXG4gICAgfSlcbiAgICAucHJvbWlzZSgpO1xuXG4gIC8vIGNhbGwgZG93bnN0cmVhbSBmdW5jdGlvbiBhbmQgY2FwdHVyZSByZXNwb25zZVxuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGxhbWJkYVxuICAgIC5pbnZva2Uoe1xuICAgICAgRnVuY3Rpb25OYW1lOiBwcm9jZXNzLmVudi5ET1dOU1RSRUFNX0ZVTkNUSU9OX05BTUUgPz8gXCJcIixcbiAgICAgIFBheWxvYWQ6IEpTT04uc3RyaW5naWZ5KGV2ZW50KSxcbiAgICB9KVxuICAgIC5wcm9taXNlKCk7XG5cbiAgY29uc29sZS5sb2coXCJkb3duc3RyZWFtIHJlc3BvbnNlOlwiLCBKU09OLnN0cmluZ2lmeShyZXNwb25zZSwgdW5kZWZpbmVkLCAyKSk7XG5cbiAgaWYgKHJlc3BvbnNlPy5QYXlsb2FkKSB7XG4gICAgLy8gcmV0dXJuIHJlc3BvbnNlIGJhY2sgdG8gdXBzdHJlYW0gY2FsbGVyXG4gICAgcmV0dXJuIEpTT04ucGFyc2UocmVzcG9uc2U/LlBheWxvYWQgYXMgc3RyaW5nKTtcbiAgfVxufTtcbiJdfQ==